/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.util.Objects;

/**
 *
 * @author user
 */
public class Alianca
{

    private Personagem personagem_a;
    private Personagem personagem_b;
    private boolean publica;
    private double fatorCompatibilidade;

    public Alianca(Personagem a, Personagem b, boolean publica, double fatorCompatibilidade)
    {
        this.personagem_a = a;
        this.personagem_b = b;
        this.publica = publica;
        this.fatorCompatibilidade = fatorCompatibilidade;
    }

    /**
     * @return the personagem_a
     */
    public Personagem getPersonagem_a()
    {
        return personagem_a;
    }

    /**
     * @return the personagem_b
     */
    public Personagem getPersonagem_b()
    {
        return personagem_b;
    }

    /**
     * @return the publica
     */
    public boolean isPublica()
    {
        return publica;
    }

    /**
     * @return the fatorCompatibilidade
     */
    public double getFatorCompatibilidade()
    {
        return fatorCompatibilidade;
    }

    /**
     * @param personagem_a the personagem_a to set
     */
    public void setPersonagem_a(Personagem personagem_a)
    {
        this.personagem_a = personagem_a;
    }

    /**
     * @param personagem_b the personagem_b to set
     */
    public void setPersonagem_b(Personagem personagem_b)
    {
        this.personagem_b = personagem_b;
    }
   
    /**
     * @param publica the publica to set
     */
    public void setPublica(boolean publica)
    {
        this.publica = publica;
    }

    /**
     * @param fatorCompatibilidade the fatorCompatibilidade to set
     */
    public void setFatorCompatibilidade(double fatorCompatibilidade)
    {
        this.fatorCompatibilidade = fatorCompatibilidade;
    }
    @Override
    public int hashCode()
    {
        int hash = 3;
        hash = 11 * hash + Objects.hashCode(this.personagem_a);
        hash = 11 * hash + Objects.hashCode(this.personagem_b);
        return hash;
    }
    
    public double calcularForcaAlianca(Alianca a){
        double forcaAlianca;
        double forcaAliado1 = a.getPersonagem_a().getNumeroPontos();
        double forcaAliado2 = a.getPersonagem_b().getNumeroPontos();
        forcaAlianca = (forcaAliado1 + forcaAliado2) * a.getFatorCompatibilidade();
        return forcaAlianca;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        final Alianca other = (Alianca) obj;
        if (!Objects.equals(this.personagem_a, other.personagem_a))
        {
            return false;
        }
        if (!Objects.equals(this.personagem_b, other.personagem_b))
        {
            return false;
        }
        return true;
    }

    

}
