/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import listas.ListaLocais;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;
import matrixGraph.AdjacencyMatrixGraph;

/**
 *
 * @author user
 */
public class Controller
{
    private MapaJogo mapaJogo;
    private RedeAliancas mapaAliancas;
    

    // Ficheiros de Import
    private String ficheiro_mapa;
   
    //--------------------------
    private HashMap<Personagem, Set<Local>> donos_local;
    private LinkedList<Alianca> aliancas;
    private ListaLocais listaLocais;
    
  
    
    public Controller(){
        mapaJogo = new MapaJogo();
    }




}
