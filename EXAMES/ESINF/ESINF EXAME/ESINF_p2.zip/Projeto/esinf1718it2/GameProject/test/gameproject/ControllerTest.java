/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class ControllerTest {

    private Controller instance;

    private static final String LOCAIS_S = "Locais_.txt";
    private static final String PERSONAGENS = "Pers_S.txt";

    public ControllerTest() throws FileNotFoundException {
        instance = new Controller();
        instance.loadMapa();
        instance.loadPersonagens();
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of loadMapa method, of class Controller.
     */
    @Test
    public void testLoadMapa() throws Exception {
        System.out.println("loadMapa");
        assertTrue("Should be true", instance.getMapaJogo().getNumLocais() == 30);
    }

    /**
     * Test of loadPersonagens method, of class Controller.
     */
    @Test
    public void testLoadPersonagens() throws Exception {
        System.out.println("loadPersonagens");
        assertTrue("Should be true", instance.getRedePersonagens().getNumPersonagens() == 10);
    }

    /**
     * Test of obterLocal method, of class Controller.
     */
    @Test
    public void testObterLocal() {
        System.out.println("obterLocal");
        String nome = "Local0";
        Local l = instance.obterLocal(nome);
        assertTrue("Should be true", l.getDificuldade() == 30);
    }

    ;

    /**
     * Test of inicializarLocal method, of class Controller.
     */
    @Test
    public void testInicializarLocal() {
        System.out.println("inicializarLocal");
        Personagem p = new Personagem("PersX", 10);
        Local l = new Local("LocalX", 30);
        assertTrue("Should be true", instance.getDonos_Locais().get(p) == null);
        instance.getMapaJogo().adicionarLocal(l);
        instance.getRedePersonagens().adicionarPersonagem(p);
        Set<Local> locais = new HashSet();
        locais.add(l);
        instance.inicializarLocal(p, locais);
        assertTrue("Should be true", instance.getDonos_Locais().get(p) != null);
        instance.getMapaJogo().getMapaJogo().removeVertex(l);
        instance.getRedePersonagens().getGraph().removeVertex(p);
    }

    /**
     * Test of podeConquistar method, of class Controller.
     */
    @Test
    public void testPodeConquistar_Personagem_Local() {
        System.out.println("podeConquistar");
        Personagem pA = instance.obterPersonagem("Pers0");
        Personagem pB = instance.obterPersonagem("Pers6");
        Local l1 = instance.obterLocal("Local2");
        Local l2 = instance.obterLocal("Local14");
        ArrayList<String> result = instance.podeConquistar(pA, l2);
        assertTrue("Should be true", result.get(0).equalsIgnoreCase("true"));
        result = instance.podeConquistar(pB, l1);

    }

    /**
     * Test of donoDeLocal method, of class Controller.
     */
    @Test
    public void testDonoDeLocal() {
        System.out.println("donoDeLocal");
        Local local = instance.obterLocal("Local10");
        Controller instance = new Controller();
        Personagem expResult = instance.getRedePersonagens().getPersonagemPorNome("Pers4");
        Personagem result = instance.donoDeLocal(local);
        assertEquals(expResult, result);
    }

    /**
     * Test of caminhoMaisCurto method, of class Controller.
     */
    @Test
    public void testCaminhoMaisCurto() {
        System.out.println("\ncaminhoMaisCurto");
        Personagem p = instance.obterPersonagem("Pers1");
        Set<Local> propriedades = instance.getDonos_Locais().get(p);
        Local localDest = instance.obterLocal("Local3");
        LinkedList<Local> resultado = instance.caminhoMaisCurto(propriedades, localDest);
        assertTrue("Should be true!", resultado.size() == 3);
        System.out.println("TOOOOOOOOOOPPPPPPPPPPPP");
        for (Local l : resultado) {
            System.out.print(l.getNome() + " ");
        }
//        assertTrue("Should be true!", resultado.g;

    }

    /**
     * Test of calcularPercursoConquista method, of class Controller. 25 + [26 +
     * 121] + 24 + [21 + 195] + 24 + [38]= 474
     */
    @Test
    public void testCalcularPercursoConquista() {
        System.out.println("calcularPercursoConquista");
        LinkedList<Local> caminho = new LinkedList<>();
        Local local_1 = instance.obterLocal("Local1");
        Local local_14 = instance.obterLocal("Local14");
        Local local_2 = instance.obterLocal("Local2");
        Local local_27 = instance.obterLocal("Local27");
        caminho.add(local_1);
        caminho.add(local_14);
        caminho.add(local_2);
        caminho.add(local_27);
        System.out.println(instance.calcularPercursoConquista(caminho));
        assertTrue("Should be true", instance.calcularPercursoConquista(caminho) > 473);
    }

    /**
     * Test of calcularPontosLocal method, of class Controller.
     */
    @Test
    public void testCalcularPontosLocal() {
        System.out.println("calcularPontosLocal");
        Local local_0 = instance.obterLocal("Local0");
        double result = instance.calcularPontosLocal(local_0);
        assertTrue("Should be true", result == (double) 30);

    }

    /**
     * Test of nomesLocaisConquista method, of class Controller.
     */
    @Test
    public void testNomesLocaisConquista() {
        System.out.println("nomesLocaisConquista");
        Local loc_10 = instance.obterLocal("Local10");
        Local loc_14 = instance.obterLocal("Local14");
        Local loc_23 = instance.obterLocal("Local23");
        LinkedList<Local> caminho = new LinkedList<>();
        caminho.add(loc_10);
        caminho.add(loc_14);
        caminho.add(loc_23);
        ArrayList<String> result = instance.nomesLocaisConquista(caminho);
        assertTrue("Should Be true", result.get(0).equalsIgnoreCase("Local14"));
        assertTrue("Should Be true", result.get(1).equalsIgnoreCase("Local23"));

    }

    /**
     * Test of grafoNovasAliancas method, of class Controller.
     */
    @Test
    public void testGrafoNovasAliancas() {
        System.out.println("grafoNovasAliancas");
        Controller instance = new Controller();
        RedePersonagens expResult = null;
        RedePersonagens result = instance.grafoNovasAliancas();
        System.out.println("Total Novas Aliancas");
        System.out.println(result.getNumAliancas());
        // Não Acabado

    }

    /**
     * Test of conquistaComAliado method, of class Controller.
     */
//    @Test
////    public void testConquistaComAliado() {
////        System.out.println("conquistaComAliado");
////        Personagem p ) 
////     
////    }
    /**
     * Test of calcularConquistaDeAlianca method, of class Controller.
     */
    @Test
    public void testCalcularConquistaDeAlianca() {
        System.out.println("calcularConquistaDeAlianca");
        Personagem p = instance.obterPersonagem("Pers1");
        Personagem aliado = instance.obterPersonagem("Pers3");
        Local localDestino = instance.obterLocal("Local20");
        ArrayList<String> result = instance.calcularConquistaDeAlianca(p, aliado, localDestino);
        assertTrue("sHOULD BE TRUE", result.get(0).equalsIgnoreCase("false"));
        localDestino = instance.obterLocal("Local14");
        result = instance.calcularConquistaDeAlianca(p, aliado, localDestino);
        assertTrue("sHOULD BE TRUE", result.get(0).equalsIgnoreCase("true"));

    }

    /**
     * Test of validarLocaisIntermedios method, of class Controller.
     */
    @Test
    public void testValidarLocaisIntermedios() {
        System.out.println("validarLocaisIntermedios");
        Personagem p = instance.obterPersonagem("Pers1");
        ArrayList<Local> caminho_a = new ArrayList<>();
        caminho_a.add(instance.obterLocal("Local1"));
        caminho_a.add(instance.obterLocal("Local4"));
        caminho_a.add(instance.obterLocal("Local6"));
        ArrayList<Local> caminho_b = new ArrayList<>();
        caminho_b.add(instance.obterLocal("Local1"));
        caminho_b.add(instance.obterLocal("Local14"));
        caminho_b.add(instance.obterLocal("Local2"));
        assertTrue("should be true", instance.validarLocaisIntermedios(caminho_a, p) == false);
        assertTrue("should be true", instance.validarLocaisIntermedios(caminho_b, p) == true);
    }

    /**
     * Test of podeConquistar method, of class Controller.
     */
    @Test
    public void testPodeConquistar_ArrayList() {
        System.out.println("podeConquistar");
        ArrayList<String> conquista = new ArrayList<>();
        conquista.add("false");
        conquista.add("350");
        conquista.add("localx");
        assertTrue("should be true", instance.podeConquistar(conquista) == false);
        conquista.set(0, "TrUe");
        assertTrue("should be true", instance.podeConquistar(conquista) == true);

    }

}
