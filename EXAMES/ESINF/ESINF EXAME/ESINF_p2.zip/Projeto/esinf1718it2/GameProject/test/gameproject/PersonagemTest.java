/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class PersonagemTest {

    private Personagem instance;

    public PersonagemTest() {
        instance = new Personagem("PersX", 35);
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getNome method, of class Personagem.
     */
    @Test
    public void testGetNome() {
        System.out.println("getNome");
        assertTrue("Should be true", instance.getNome().equalsIgnoreCase("PersX"));

    }

    /**
     * Test of getNumeroPontos method, of class Personagem.
     */
    @Test
    public void testGetNumeroPontos() {
        System.out.println("getNumeroPontos");
        assertTrue("Should be true", instance.getNumeroPontos() == 35);

    }

    /**
     * Test of setNome method, of class Personagem.
     */
    @Test
    public void testSetNome() {

        instance.setNome("PersY");
        assertTrue("Should be true", instance.getNome().equalsIgnoreCase("PersY"));
    }

    /**
     * Test of equals method, of class Personagem.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Personagem p1 = new Personagem("PersZ", 30);
        Personagem p2 = new Personagem("PersX", 400);
        Personagem p3 = new Personagem("PersZ", 50);
        assertTrue("Should be true", p1.equals(p2) == false);
        assertTrue("Should be true", p1.equals(p3) == true);

    }

    /**
     * Test of setNumeroPontos method, of class Personagem.
     */
    @Test
    public void testSetNumeroPontos() {
        System.out.println("setNumeroPontos");
        instance.setNumeroPontos(500);
        assertTrue("Should be true", instance.getNumeroPontos() == 500);
    }

}
