/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import adjacencyMap.Edge;
import adjacencyMap.Graph;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class RedePersonagensTest {

    private static final String PERSONAGENS_S = "pers_S.txt";
    private static final String LOCAIS_S = "locais_S.txt";
    private RedePersonagens instance;
    private Controller ctrl;

    public RedePersonagensTest() throws FileNotFoundException {
        ctrl = new Controller();
        ctrl.getMapaJogo().importarDadosMapa(LOCAIS_S);
        instance = new RedePersonagens(ctrl);
        instance.importarDadosPersonagens(PERSONAGENS_S);
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of importarDadosPersonagens method, of class RedePersonagens.
     */
    @Test
    public void testImportarDadosPersonagens() throws Exception {
        System.out.println("importarDadosPersonagens");
        boolean result = instance.importarDadosPersonagens(PERSONAGENS_S);
        assertTrue("Should be True", result);
        assertTrue("Should be True", instance.getNumPersonagens() == 10);
        assertTrue("Should be True", instance.getPersonagemPorNome("Pers10") == null);
        assertTrue("Should be True", instance.getPersonagemPorNome("Pers7") != null);

    }

    /**
     * Test of adicionarPersonagem method, of class RedePersonagens.
     */
    @Test
    public void testAdicionarPersonagem() {
        System.out.println("adicionarPersonagem");
        assertTrue("Should be True", instance.getPersonagemPorNome("PersX") == null);
        Personagem p = new Personagem("PersX", 50);
        instance.adicionarPersonagem(p);
        assertTrue("Should be True", instance.getPersonagemPorNome("PersX") != null);

    }

    /**
     * Test of localInicioDePersonagem method, of class RedePersonagens.
     */
    @Test
    public void testLocalInicioDePersonagem() {
        System.out.println("localInicioDePersonagem");
        Local l = new Local("LocalX", 0);
        this.ctrl.getMapaJogo().adicionarLocal(l);
        Set<Local> locais = new HashSet();
        locais.add(l);
        Personagem pX = new Personagem("PersX", 0);
        instance.adicionarPersonagem(pX);
        instance.localInicioDePersonagem(pX, locais);
        assertTrue("Should be True", ctrl.donoDeLocal(l).equals(pX));
        instance.getGraph().removeVertex(pX);
        ctrl.getMapaJogo().getMapaJogo().removeVertex(l);

    }

    /**
     * Test of adicionarAlianca method, of class RedePersonagens.
     */
    @Test
    public void testAdicionarAlianca() {
        System.out.println("adicionarAlianca");
        Personagem pA = instance.getPersonagemPorNome("Pers1");
        Personagem pB = instance.getPersonagemPorNome("Pers7");
        boolean publica = true;
        double fator_Comp = 0.5;
        boolean result = instance.adicionarAlianca(pA, pB, publica, fator_Comp);
        assertTrue("Should be True", result);
        assertTrue("Should be True", instance.removerAlianca(pB, pA) == true);

    }

    /**
     * Test of getPersonagemPorNome method, of class RedePersonagens.
     */
    @Test
    public void testGetPersonagemPorNome() {
        System.out.println("getPersonagemPorNome");
        Personagem pA = instance.getPersonagemPorNome("Pers0");
        Personagem pB = instance.getPersonagemPorNome("Pers9");
        Personagem pC = instance.getPersonagemPorNome("Pers10");

        assertTrue("Should be True", pA.getNome().equalsIgnoreCase("Pers0"));
        assertTrue("Should be True", pB != null);
        assertTrue("Should be True", pC == null);

    }

    /**
     * Test of getAlianca method, of class RedePersonagens.
     */
    @Test
    public void testGetAlianca() {
        System.out.println("getAlianca");
        Personagem pA = instance.getPersonagemPorNome("Pers0");
        Personagem pB = instance.getPersonagemPorNome("Pers1");
        Personagem pC = instance.getPersonagemPorNome("Pers2");
        assertTrue("Should be True", pA != null);
        assertTrue("Should be True", pB != null);
        assertTrue("Should be True", pC != null);
        assertTrue("Should be True", instance.getAlianca(pA, pB) == null);
        assertTrue("Should be True", instance.getAlianca(pB, pC) != null);

    }

    /**
     * Test of getNumPersonagens method, of class RedePersonagens.
     */
    @Test
    public void testGetNumPersonagens() {
        System.out.println("getNumPersonagens");

        assertTrue("Should be True", instance.getNumPersonagens() == 10);
    }

    /**
     * Test of getNumAliancas method, of class RedePersonagens.
     */
    @Test
    public void testGetNumAliancas() {
        System.out.println("getNumAliancas");
        Personagem pA = instance.getPersonagemPorNome("Pers1");
        Personagem pB = instance.getPersonagemPorNome("Pers7");
        boolean publica = true;
        double fator_Comp = 0.5;
        assertTrue("Should be True", instance.getNumAliancas() == 10);
        assertTrue(instance.adicionarAlianca(pA, pB, publica, fator_Comp));
        assertTrue("Should be True", instance.getNumAliancas() == 11);
        instance.removerAlianca(pA, pB);
        assertTrue("Should be True", instance.getNumAliancas() == 10);
    }

    /**
     * Test of existePersonagem method, of class RedePersonagens.
     */
    @Test
    public void testExistePersonagem() {
        System.out.println("existePersonagem");
        Personagem p = new Personagem("PersX", 300);
        assertTrue("Should be True", instance.getPersonagemPorNome("PersX") == null);
        assertTrue("Should be True", instance.getPersonagemPorNome("Pers3") != null);
    }

    /**
     * Test of obterLocal method, of class RedePersonagens.
     */
    @Test
    public void testObterLocal() {
        System.out.println("obterLocal");
        Local l = instance.obterLocal("LocalX");
        Local l2 = instance.obterLocal("Local10");
        assertTrue("Should be true", l == null);
        assertTrue("Should be true", l2 != null);
    }

    /**
     * Test of getListaPersonagens method, of class RedePersonagens.
     */
    @Test
    public void testGetListaPersonagens() {
        System.out.println("getListaPersonagens");

        Iterator<Personagem> listaPer = instance.getListaPersonagens().iterator();
        assertTrue("Should be true", listaPer.next().getNome().equalsIgnoreCase("Pers0"));
    }

    /**
     * Test of listaTotalAliancas method, of class RedePersonagens.
     */
    @Test
    public void testListaTotalAliancas() {
        System.out.println("listaTotalAliancas");
        Iterable<Edge<Personagem, Boolean>> result = instance.listaTotalAliancas();
        Iterator<Edge<Personagem, Boolean>> it = result.iterator();
        int i = 0;
        while (it.hasNext()) {
            Edge<Personagem, Boolean> alianca = it.next();
            i++;
        }
        assertTrue("Should be true", i == instance.getNumAliancas() * 2);

    }

    /**
     * Test of aliadosPersonagem method, of class RedePersonagens.
     */
    @Test
    public void testAliadosPersonagem() {
        System.out.println("aliadosPersonagem");
        Personagem pA = instance.getPersonagemPorNome("Pers3");
        Personagem pB = instance.getPersonagemPorNome("Pers4");
        Personagem pC = instance.getPersonagemPorNome("Pers7");
        ArrayList<Personagem> result = instance.aliadosPersonagem(pA);
        assertTrue("Should be true", result.contains(pB));
        assertTrue("Should be true", result.contains(pC) == false);

    }

    /**
     * Test of calcularForcaAlianca method, of class RedePersonagens.
     */
    @Test
    public void testCalcularForcaAlianca() {
        System.out.println("calcularForcaAlianca");
        Personagem pA = instance.getPersonagemPorNome("Pers3");
        Personagem pB = instance.getPersonagemPorNome("Pers4");
        Edge<Personagem, Boolean> alianca = instance.getAlianca(pA, pB);

        double expResult = 345.5; //(429+262) * 0.5

        assertTrue(instance.calcularForcaAlianca(pA, pB, (float) alianca.getWeight()) == expResult);

    }

    /**
     * Test of aliancaMaisForte method, of class RedePersonagens.
     */
    @Test
    public void testAliancaMaisForte() {
        System.out.println("aliancaMaisForte");

        String result = instance.aliancaMaisForte();
        String[] str = result.split(":");
        assertTrue("Should be true", str[1].equalsIgnoreCase("Pers0"));
        assertTrue("Should be true", str[2].equalsIgnoreCase("Pers3"));
        assertTrue("Should be true", Double.parseDouble(str[4]) > 499);

    }

    /**
     * Test of criarNovaAlianca method, of class RedePersonagens.
     */
    @Test
    public void testCriarNovaAlianca() {
        System.out.println("criarNovaAlianca");
        Personagem p2 = instance.getPersonagemPorNome("Pers2");
        Personagem p5 = instance.getPersonagemPorNome("Pers5");
        boolean result = instance.criarNovaAlianca(p5, p2);
        assertTrue("should be true", result);
        //----- 
        Personagem p0 = instance.getPersonagemPorNome("Pers0");
        result = instance.criarNovaAlianca(p0, p2);
        assertTrue("should be true", result);

    }

    /**
     * Test of caminhoMaisPerto method, of class RedePersonagens.
     */
    @Test
    public void testCaminhoMaisPerto() {
        System.out.println("caminhoMaisPerto");
        Personagem a = instance.getPersonagemPorNome("Pers0");
        Personagem b = instance.getPersonagemPorNome("Pers1");
        LinkedList<Personagem> result = instance.caminhoMaisPerto(a, b);
        assertTrue("should be true", result.size() == 3);
    }

    /**
     * Test of novoFatorDeCompatibilidade method, of class RedePersonagens.
     */
    @Test
    public void testNovoFatorDeCompatibilidade() {
        System.out.println("novoFatorDeCompatibilidade");
        Personagem p1 = instance.getPersonagemPorNome("Pers1");
        
        Personagem p2 = instance.getPersonagemPorNome("Pers2");
        Personagem p4 = instance.getPersonagemPorNome("Pers4");
        LinkedList<Personagem> menorCaminho = new LinkedList<>();
        menorCaminho.add(p1);
        menorCaminho.add(p2);
        menorCaminho.add(p4);
        
        double fator = instance.novoFatorDeCompatibilidade(menorCaminho);
        System.out.println("Fator comp:" + fator);

    }

    /**
     * Test of existeAlianca method, of class RedePersonagens.
     */
    @Test
    public void testExisteAlianca() {
        System.out.println("existeAlianca");
        Personagem pA = instance.getPersonagemPorNome("Pers3");
        Personagem pB = instance.getPersonagemPorNome("Pers4");
        Personagem pC = instance.getPersonagemPorNome("Pers7");
        assertTrue("Should be true", instance.existeAlianca(pA, pB));
        assertTrue("Should be true", instance.existeAlianca(pB, pA));
        assertTrue("Should be true", instance.existeAlianca(pA, pC) == false);

    }

//    /**
//     * Test of aliancasPublicas method, of class RedePersonagens.
//     */
//    @Test
//    public void testAliancasPublicas() {
//        System.out.println("aliancasPublicas");
//        LinkedList<Personagem> min = null;
//        Personagem p5 = instance.getPersonagemPorNome("Pers5");
//        Personagem p7 = instance.getPersonagemPorNome("Pers7");
//        Personagem p8 = instance.getPersonagemPorNome("Pers8");
//
//        min.add(p8);
//        min.add(p7);
//        assertTrue("Should be true", instance.aliancasPublicas(min) == true);
//        min.add(p5);
//        assertTrue("Should be true", instance.aliancasPublicas(min) == false);
//    }
}
