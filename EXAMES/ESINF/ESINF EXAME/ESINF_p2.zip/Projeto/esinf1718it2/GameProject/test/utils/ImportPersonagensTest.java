/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import gameproject.Controller;
import gameproject.MapaJogo;
import gameproject.RedePersonagens;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class ImportPersonagensTest {
    
    public ImportPersonagensTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of importPersonagens method, of class ImportPersonagens.
     */
    @Test
    public void testImportPersonagens() throws Exception {
        System.out.println("importPersonagens");
        String fileName = "pers_S.txt";
        Controller ctrl = new Controller();
        MapaJogo mapa = ctrl.getMapaJogo();
        mapa.importarDadosMapa("locais_S.txt");
        
        RedePersonagens instance = new RedePersonagens(ctrl);
        boolean result = ImportPersonagens.importPersonagens(fileName, instance);
        assertTrue("Should be True", instance.getNumPersonagens()==10);
        assertTrue("Should be True", instance.getNumAliancas()==10);

    }
    
}
