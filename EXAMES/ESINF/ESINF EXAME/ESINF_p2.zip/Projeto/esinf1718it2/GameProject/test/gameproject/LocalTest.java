/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class LocalTest
{

    public LocalTest()
    {
    }

    @BeforeClass
    public static void setUpClass()
    {
    }

    @AfterClass
    public static void tearDownClass()
    {
    }

    @Before
    public void setUp()
    {
    }

    @After
    public void tearDown()
    {
    }

    /**
     * Test of getNome method, of class Local.
     */
    @Test
    public void testGetNome()
    {
        System.out.println("getNome");
        Local instance = new Local("porto", 5);
        String expResult = "porto";
        String result = instance.getNome();
        assertEquals(expResult, result);
    }

    /**
     * Test of getDificuldade method, of class Local.
     */
    @Test
    public void testGetDificuldade()
    {
        System.out.println("getDificuldade");
        Local instance = new Local("porto", 15);
        int expResult = 15;
        int result = instance.getDificuldade();
        assertEquals(expResult, result);
    }

    /**
     * Test of setNome method, of class Local.
     */
    @Test
    public void testSetNome()
    {
        System.out.println("setNome");
        String nome = "porto";
        Local instance = new Local("gaia", 10);
        instance.setNome(nome);
    }

    

    /**
     * Test of setDificuldade method, of class Local.
     */
    @Test
    public void testSetDificuldade()
    {
        System.out.println("setDificuldade");
        int dificuldade = 10;
        Local instance = new Local("porto", 15);
        instance.setDificuldade(dificuldade);
    }

    /**
     * Test of hashCode method, of class Local.
     */
    @Test
    public void testHashCode()
    {
        System.out.println("hashCode");
        Local instance = new Local("porto", 10);
        Local instance2 = new Local("porto", 10);
        Assert.assertTrue(instance.hashCode() == instance2.hashCode());
    }

    /**
     * Test of equals method, of class Local.
     */
    @Test
    public void testEquals()
    {
        System.out.println("equals");
        Local instance = new Local("porto", 10);
        Local instance2 = new Local("porto", 10);
        Assert.assertTrue(instance.equals(instance2) && instance2.equals(instance2));
    }

}
