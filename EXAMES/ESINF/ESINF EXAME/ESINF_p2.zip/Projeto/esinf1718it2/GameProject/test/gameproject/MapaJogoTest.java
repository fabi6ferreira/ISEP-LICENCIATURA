/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import matrixGraph.AdjacencyMatrixGraph;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class MapaJogoTest {

    private static final String LOCAIS_S = "locais_S.txt";
    private MapaJogo instance;

    public MapaJogoTest() throws FileNotFoundException {
        instance = new MapaJogo();
        instance.importarDadosMapa(LOCAIS_S);
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of importarDadosMapa method, of class MapaJogo.
     */
    @Test
    public void testImportarDadosMapa() throws Exception {
        System.out.println("importMapa");

        boolean result = instance.importarDadosMapa(LOCAIS_S);
        assertTrue("Should be true", result);
        assertTrue("Should be True", instance.getNumLocais() == 30);
        assertTrue("Should be True", instance.getLocalPorNome("local40") == null);
        assertTrue("Should be True", instance.getLocalPorNome("local20") != null);

        Local l1 = instance.getLocalPorNome("Local0");
        Local l2 = instance.getLocalPorNome("Local18");
        Local l3 = instance.getLocalPorNome("Local29");
        Local l4 = new Local("Local30", 9);
        assertTrue("Should be True", instance.getNumEstradas() == 132);
        assertTrue("Should be True", instance.getEstrada(l1, l2) == 29);
        assertTrue("Should be True", instance.getEstrada(l2, l1) == 29);

        assertTrue("Should be True", instance.getEstrada(l3, l4) == null);
    }

    /**
     * Test of getMapaJogo method, of class MapaJogo.
     */
    @Test
    public void testGetMapaJogo() {
        System.out.println("getMapaJogo");
        AdjacencyMatrixGraph<Local, Double> result = instance.getMapaJogo();
        Iterator<Local> it = result.vertices().iterator();
        Local l1 = new Local("Local13", 31);
        Local l2 = new Local("Local22", 32);

        assertTrue("Should Be true", result.getEdge(l1, l2) == null);
        l1 = new Local("Local11", 36);
        l2 = new Local("Local14", 26);
        assertTrue("Should Be true", result.getEdge(l1, l2) == 27);

    }

    /**
     * Test of adicionarLocal method, of class MapaJogo.
     */
    @Test
    public void testAdicionarLocal() {
        System.out.println("adicionarLocal");
        Local local = new Local("LocalX", 30);

        boolean expResult = true;
        boolean result = instance.adicionarLocal(local);
        assertEquals(expResult, result);
        Local l = instance.getLocalPorNome("LocalX");
        assertTrue("Should be true", l != null);
        assertTrue("Should be true", l.getDificuldade() == 30);
        assertTrue("Should be true", instance.getMapaJogo().removeVertex(l));
        assertTrue("Should be true", instance.getLocalPorNome("LocalX") == null);

    }

    /**
     * Test of adicionarEstrada method, of class MapaJogo.
     */
    @Test
    public void testAdicionarEstrada() {
        System.out.println("adicionarEstrada");
        Local local1 = new Local("LocalX", 30);
        Local local2 = new Local("LocalY", 30);
        instance.adicionarLocal(local1);
        instance.adicionarLocal(local2);
        double dificuldade = 50;
        boolean result = instance.adicionarEstrada(local1, local2, dificuldade);
        assertTrue("Should be true", result);
        result = instance.adicionarEstrada(local1, local2, dificuldade);
        assertFalse("Should be False", result);
        instance.getMapaJogo().removeEdge(local2, local1);
        assertTrue("Should be true", instance.getMapaJogo().getEdge(local1, local2) == null);
        instance.getMapaJogo().removeVertex(local1);
        instance.getMapaJogo().removeVertex(local2);

    }

    /**
     * Test of getLocalPorNome method, of class MapaJogo.
     */
    @Test
    public void testGetLocalPorNome() {
        System.out.println("getLocalPorNome");
        Local result = instance.getLocalPorNome("Local4");
        assertTrue("Should be true", result.getNome().equalsIgnoreCase("Local4"));
        assertTrue("Should be true", result.getDificuldade() == 30);
        result = instance.getLocalPorNome("Local30");
        assertTrue("Should be true", result == null);

    }

    /**
     * Test of getEstrada method, of class MapaJogo.
     */
    @Test
    public void testGetEstrada() {
        System.out.println("getEstrada");
        Local local_1 = instance.getLocalPorNome("Local0");
        Local local_2 = instance.getLocalPorNome("Local2");
        Local local_3 = instance.getLocalPorNome("Local0");
        Local local_4 = instance.getLocalPorNome("Local3");
        assertTrue("Should be true", instance.getEstrada(local_1, local_2) == null);
        assertTrue("Should Be true", instance.getEstrada(local_3, local_4) == 20);
    }

    /**
     * Test of getNumLocais method, of class MapaJogo.
     */
    @Test
    public void testGetNumLocais() {
        System.out.println("getNumLocais");
        assertTrue("Should be true", instance.getNumLocais() == 30);

    }

    /**
     * Test of getNumEstradas method, of class MapaJogo.
     */
    @Test
    public void testGetNumEstradas() {
        System.out.println("getNumEstradas");
        int expResult = 0;
        assertTrue("Should be true", instance.getNumEstradas() == 132);
    }

    /**
     * Test of caminhoMenorDificuldade method, of class MapaJogo.
     */
    @Test
    public void testCaminhoMenorDificuldade() {
        System.out.println("caminhoMenorDificuldade");
        Local localOrig = instance.getLocalPorNome("Local0");
        Local localDest = instance.getLocalPorNome("Local14");
        Local intermedio = instance.getLocalPorNome("Local12");
        LinkedList<Local> min = new LinkedList<>();
        min = instance.caminhoMenorDificuldade(localOrig, localDest);
        Iterator<Local> it = min.listIterator();
        int i = 0;
        boolean flagLocal12 = false;
        while (it.hasNext()) {
            if (it.next().equals(intermedio)) {
                flagLocal12 = true;
            };
            i++;
        }
        assertTrue("Should be true! Local0, Local,Local14", i == 3);
        assertTrue("Should be true!", flagLocal12);

    }

    /**
     * Test of caminhoMaisCurto method, of class MapaJogo.
     */
    @Test
    public void testCaminhoMaisCurto() {
        System.out.println("caminhoMaisCurto");
        Local localOrig = instance.getLocalPorNome("Local1");
        Local localDest = instance.getLocalPorNome("Local14");

        LinkedList<Local> min = new LinkedList<>();
        min = instance.caminhoMaisCurto(localOrig, localDest);
        Iterator<Local> it = min.listIterator();
        int i = 0;
        while (it.hasNext()) {
            it.next();
            i++;
        }
        assertTrue("Should be true! Exists direct path", i == 2);
        localOrig = instance.getLocalPorNome("Local0");
        localDest = instance.getLocalPorNome("Local14");
        Local intermedio1 = instance.getLocalPorNome("Local1");
        min = instance.caminhoMaisCurto(localOrig, localDest);
        i = 0;
        boolean flagLocal1 = false;
        Iterator<Local> it2 = min.listIterator();
        while (it2.hasNext()) {
            Local x = it2.next();
            System.out.println(x.getNome());
            if (x.equals(intermedio1)) {
                flagLocal1 = true;
            };
            i++;
        }
        assertTrue("Should be true!", i == 3);
        assertTrue("Should be true!",flagLocal1);

    }

    /**
     * Test of resetDificuldadeEstradas method, of class MapaJogo.
     */
    @Test
    public void testResetDificuldadeEstradas() {
        System.out.println("resetDificuldadeEstradas");
        AdjacencyMatrixGraph<Local, Double> clonedGraph = (AdjacencyMatrixGraph<Local, Double>) instance.getMapaJogo().clone();
        AdjacencyMatrixGraph<Local, Double> result = instance.resetDificuldadeEstradas(clonedGraph);
        Local local1 = instance.getLocalPorNome("Local0");
        Local local2 = instance.getLocalPorNome("Local12");
        assertTrue("Should be true", instance.getEstrada(local1, local2) == 23);
        assertTrue("Should be true", result.getEdge(local1, local2) == 1);
    }


}
