/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import gameproject.Local;
import gameproject.MapaJogo;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class ImportMapaTest {

    public ImportMapaTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of importMapa method, of class ImportMapa.
     */
    @Test
    public void testImportMapa() throws Exception {
        System.out.println("importMapa");
        String fileName = "locais_s.txt";
        MapaJogo mapaJogo = new MapaJogo();

        boolean result = ImportMapa.importMapa(fileName, mapaJogo);
        assertTrue("Should be true", result);
        assertTrue("Should be True", mapaJogo.getNumLocais() == 30);
        assertTrue("Should be True", mapaJogo.getLocalPorNome("local40") == null);
        assertTrue("Should be True", mapaJogo.getLocalPorNome("local20") != null);

        Local l1 = mapaJogo.getLocalPorNome("Local0");
        Local l2 = mapaJogo.getLocalPorNome("Local18");
        assertTrue("Should be True", mapaJogo.getNumEstradas() == 132);
        assertTrue("Should be True", mapaJogo.getEstrada(l1, l2) ==29);
        assertTrue("Should be True", mapaJogo.getEstrada(l2, l1) ==29);

    }
}
