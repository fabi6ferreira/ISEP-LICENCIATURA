/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.util.Objects;
import java.util.Set;

/**
 *
 * @author user
 */
public class Personagem implements Comparable<Personagem> {

    private String nome;
    private int numeroPontos;

    public Personagem(String nome, int numeroPontos) {
        this.nome = nome;
        this.numeroPontos = numeroPontos;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the valor_troca
     */
    public int getNumeroPontos() {
        return numeroPontos;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @param valor_troca the valor_troca to set
     */
    public void setNumeroPontos(int numeroPontos) {
        this.numeroPontos = numeroPontos;
    }

//    public boolean adicionarLocalPersonagem(String nomeLocal) {
//        if (!locais.contains(locais.getLocalPorNome(nomeLocal))) {
//            return false;
//        }
//        return locais.adicionarLocalPorNome(nomeLocal);
//    }
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.nome);
        hash = 29 * hash + this.numeroPontos;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Personagem other = (Personagem) obj;
        return this.getNome().equalsIgnoreCase(other.getNome());
    }

    @Override
    public int compareTo(Personagem o) {

        return this.getNome().compareTo(o.getNome()); //To change body of generated methods, choose Tools | Templates.
    }

}
