/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import adjacencyMap.Edge;
import adjacencyMap.Graph;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import matrixGraph.AdjacencyMatrixGraph;

/**
 *
 * @author user
 */
public class Controller {

    private MapaJogo mapaJogo;
    private RedePersonagens redePersonagens;
    private Map<Personagem, Set<Local>> donos_de_locais;

    // Ficheiros de Import
    private static final String ficheiro_mapa = "locais_S.txt";
    private static final String ficheiro_personagens = "Pers_S.txt";

    public Controller() {
        mapaJogo = new MapaJogo();
        donos_de_locais = new HashMap<Personagem, Set<Local>>();
        redePersonagens = new RedePersonagens(this);

    }

    public boolean loadMapa() throws FileNotFoundException {
        return this.mapaJogo.importarDadosMapa(ficheiro_mapa);
    }

    public boolean loadPersonagens() throws FileNotFoundException {
        return this.redePersonagens.importarDadosPersonagens(ficheiro_personagens);
    }

    public Local obterLocal(String nomeLocal) {
        return this.mapaJogo.getLocalPorNome(nomeLocal);
    }

    public Personagem obterPersonagem(String nome) {
        return this.redePersonagens.getPersonagemPorNome(nome);
    }

    public MapaJogo getMapaJogo() {
        return this.mapaJogo;
    }

    public Map<Personagem, Set<Local>> getDonos_Locais() {
        return this.donos_de_locais;
    }

    public RedePersonagens getRedePersonagens() {
        return this.redePersonagens;
    }

    /**
     * Inicializa o map "donos_local", com os locais iniciais de cada personagem
     *
     * @return true or false
     */
    public boolean inicializarLocal(Personagem p, Set<Local> local) {
        this.donos_de_locais.put(p, local);
        return donos_de_locais.get(p).contains(local);
    }

    /**
     * Verifica se uma dada personagem pode ou não conquistar um determinado
     * local
     *
     * @param p - Personagem conquistadora
     * @param local - Local a conquistar
     * @return String com dados sobre possibilidade de conquista e pontos
     * necessários e nomes de locais. exemplo:
     * "[TRUE/FALSE],NrPontos,local1,local2,local3..."
     */
    public ArrayList<String> podeConquistar(Personagem p, Local local) {
        if (donoDeLocal(local).equals(p)) {
            return null;
        }
        Set<Local> propriedadesPersonagem = this.donos_de_locais.get(p);
        LinkedList<Local> caminho = caminhoMaisCurto(propriedadesPersonagem, local);
        double pontosNecessarios = calcularPercursoConquista(caminho);

        ArrayList<String> info_conquista = new ArrayList<>();
        if (p.getNumeroPontos() >= pontosNecessarios) {
            info_conquista.add("true");
            info_conquista.add(Double.toString(pontosNecessarios));
            info_conquista.addAll(nomesLocaisConquista(caminho));
        } else {
            info_conquista.add("false");
            info_conquista.add(Double.toString(pontosNecessarios));
            info_conquista.addAll(nomesLocaisConquista(caminho));
        }
        return info_conquista;
    }

    /**
     * Verifica qual o dono de um dado local
     *
     * @param local
     * @return Personagem dono de local ou Null, caso não tenha dono.
     */
    public Personagem donoDeLocal(Local local) {
        for (Entry<Personagem, Set<Local>> entry : this.donos_de_locais.entrySet()) {
            Set<Local> locais = (Set<Local>) entry.getValue();
            if (locais.contains(local)) {
                return (Personagem) entry.getKey();
            }
        }
        return null;
    }

    /**
     * Analisa todas as propriedades de uma dada personagem, e devolve qual o
     * caminho mais curto entre a propriedade mais proxima e local destino.
     *
     * @param propriedades - Locais pertencentes à personagem
     * @param localDest - Local que pretende conquistar
     * @return Local -
     */
    public LinkedList<Local> caminhoMaisCurto(Set<Local> propriedades, Local localDest) {
        LinkedList<Local> caminhoMinimo = new LinkedList<>();
        LinkedList<Local> caminhoAtual;
        for (Local propriedade : propriedades) {
            caminhoAtual = this.mapaJogo.caminhoMaisCurto(propriedade, localDest);
            Iterator<Local> itAtual = caminhoAtual.iterator();
            if (caminhoAtual.size() < caminhoMinimo.size() || caminhoMinimo.isEmpty()) {
                caminhoMinimo.clear();
                caminhoMinimo.addAll(caminhoAtual);
            }
        }
        Iterator<Local> it = caminhoMinimo.iterator();
        System.out.println("CaminhoMaisCurto");
        while(it.hasNext()){
            Local l = it.next();
            System.out.print(l.getNome()+" ");
        }
        return caminhoMinimo;
    }

    
    /**
     * Calcula pontos totais de um trajeto (Estradas + Locais + DonosDeLocais)
     * @param caminho
     * @return 
     */
    public double calcularPercursoConquista(LinkedList<Local> caminho) {
        double totalPts = 0;
        for (int i = 0; i < caminho.size() - 1; i++) {
            double ptsEstrada = this.mapaJogo.getEstrada(caminho.get(i), caminho.get(i + 1));
            double ptsDestino = calcularPontosLocal(caminho.get(i + 1));
//            System.out.println("\nPontos estrada:" + ptsEstrada);
//            System.out.println("\nPontos Destino:" + ptsDestino);
            totalPts += ptsEstrada;
            totalPts += ptsDestino;
        }
        System.out.println("Total yuikv:" + totalPts);
        return totalPts;
    }

    /**
     * Calcula os pontos totais de um dado local, considerando a sua dificuldade
     * e caso este tenha dono, adiciona os respetivos pontos.
     *
     * @param localDest
     * @return
     */
    public double calcularPontosLocal(Local localDest) {
        if (donoDeLocal(localDest) != null) {
            return localDest.getDificuldade() + donoDeLocal(localDest).getNumeroPontos();
        }
        return localDest.getDificuldade();
    }

    /**
     * Devolve os nomes dos locais intermédios (desconsidera o local origem e
     * local destino)
     *
     * @param caminho
     * @return String com lista de nomes
     */
    public ArrayList<String> nomesLocaisConquista(LinkedList<Local> caminho) {
        ArrayList<String> nomes = new ArrayList<>();
        for (int i = 1; i < caminho.size(); i++) {
            nomes.add(caminho.get(i).getNome());
        }
        for(String s:nomes){
            System.out.println(s);
        }
        return nomes;
    }

    /**
     *
     * @return
     */
    public RedePersonagens grafoNovasAliancas() {
        RedePersonagens grafoNovo = new RedePersonagens(this.redePersonagens);
        for (Edge alianca : this.redePersonagens.listaTotalAliancas()) {
            alianca.setElement(true);
        }
        for (Personagem p : redePersonagens.getListaPersonagens()) {
            for (Personagem p2 : redePersonagens.getListaPersonagens()) {
                if (!p.equals(p2) && !redePersonagens.existeAlianca(p, p2)) {
                    grafoNovo.criarNovaAlianca(p, p2);
                } else if (!p.equals(p2) && redePersonagens.existeAlianca(p, p2)) {
                    grafoNovo.adicionarAlianca(p, p2, true, Math.random());
                }
            }
        }
        return grafoNovo;
    }

    public ArrayList<String> conquistaComAliado(Personagem p, Local localDestino) {
        if (donoDeLocal(localDestino).equals(p)) {
            return null;
        }

        ArrayList<String> conquista = new ArrayList<>();
        ArrayList<String> conquista_final = new ArrayList<>();
        for (Personagem aliado : this.redePersonagens.aliadosPersonagem(p)) {
            conquista = calcularConquistaDeAlianca(p, aliado, localDestino);
            if ((podeConquistar(conquista) && (conquista.size() < conquista_final.size() - 1)) // -1, porque contem mais 1 posicao
                    || (podeConquistar(conquista) && conquista_final.size() == 0)) {
                conquista_final = conquista;
                conquista_final.add(0, aliado.getNome()); //adiciona nome aliado, na 1ª posicao
            }
        }
        return null;
    }

    /**
     *
     * @param p
     * @param aliado
     * @param localDestino
     * @return
     */
    public ArrayList<String> calcularConquistaDeAlianca(Personagem p, Personagem aliado, Local localDestino) {
        Personagem dono = donoDeLocal(localDestino);
        if (dono != null && dono.equals(aliado)) {
            return null;
        }
        Edge alianca = this.redePersonagens.getAlianca(p, aliado);
        double pontosAlianca =this.redePersonagens.calcularForcaAlianca(p, aliado,(float) alianca.getWeight());
        Set<Local> propriedadesAliado = this.donos_de_locais.get(aliado);
        System.out.println("Pontos alianca " + pontosAlianca );

        LinkedList<Local> caminho = caminhoMaisCurto(propriedadesAliado, localDestino);
        double pontosNecessarios = calcularPercursoConquista(caminho);

        ArrayList<String> info_conquista = new ArrayList<>();
        if (pontosAlianca >= pontosNecessarios) {
            info_conquista.add("true");
            info_conquista.add(Double.toString(pontosNecessarios));
            info_conquista.addAll(nomesLocaisConquista(caminho));
        } else {
            info_conquista.add("false");
            info_conquista.add(Double.toString(pontosNecessarios));
            info_conquista.addAll(nomesLocaisConquista(caminho));
        }
        return info_conquista;
    }

    /**
     * Valida locais Intermedios de um caminho calculado. verificando se nenhum
     * destes pertence à personagem passada por parametro
     *
     * @param caminho
     * @param Personagem
     * @return True (válido) caso não existam locais pertencentes à personagem
     * ou False.
     */
    public boolean validarLocaisIntermedios(ArrayList<Local> caminho, Personagem p) {
        for (Local local : caminho) {
            Personagem dono = donoDeLocal(local);
            if (dono != null && dono.equals(p)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Analisa a primeira posicao da arraylist que indica se a conquista é
     * possivel ou nao.
     *
     * @param conquista
     * @return True ou False de acordo com o valor da primeira posicao da
     * conquista
     */
    public boolean podeConquistar(ArrayList<String> conquista) {
        return conquista.get(0).equalsIgnoreCase("true");
    }

}
