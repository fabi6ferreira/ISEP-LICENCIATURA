/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import matrixGraph.*;
import utils.ImportMapa;

/**
 *
 * @author user
 */
public class MapaJogo {

    private AdjacencyMatrixGraph<Local, Double> mapaJogo;

    public MapaJogo() {
        mapaJogo = new AdjacencyMatrixGraph<>();
    }

    public boolean importarDadosMapa(String fileName) throws FileNotFoundException {
        return ImportMapa.importMapa(fileName, this);
    }

    /**
     * @return the mapaJogo
     */
    public AdjacencyMatrixGraph<Local, Double> getMapaJogo() {
        return mapaJogo;
    }

    public boolean adicionarLocal(Local local) {
        return this.mapaJogo.insertVertex(local);
    }

    public boolean adicionarEstrada(Local local1, Local local2, Double dificuldade) {
        return this.mapaJogo.insertEdge(local1, local2, dificuldade);
    }
//    public boolean inserirEstrada(Local local1, Local local2, Estrada estrada)
//    {
//        return this.mapaJogo.adicionarEstrada(local1, local2, estrada);
//    }

    public Local getLocalPorNome(String nomeLocal) {
        for (Local l : mapaJogo.vertices()) {
            if (l.getNome().equalsIgnoreCase(nomeLocal)) {
                return l;
            }
        }
        return null;
    }
    
  
    public Double getEstrada(Local local_1, Local local_2){
        return this.mapaJogo.getEdge(local_1, local_2);
    }

    public int getNumLocais() {
        return this.mapaJogo.numVertices();

    }

    public int getNumEstradas() {
        return this.mapaJogo.numEdges();

    }

    public LinkedList<Local> caminhoMenorDificuldade(Local local1, Local local2) {
        LinkedList<Local> path = new LinkedList<>();
        EdgeAsDoubleGraphAlgorithms.shortestPath(mapaJogo, local1, local2, path);
        return path;
    }

    public LinkedList<Local> caminhoMaisCurto(Local localOrig, Local localDest) {
        LinkedList<Local> minPath = new LinkedList<>();
        AdjacencyMatrixGraph<Local, Double> clonedGraph = (AdjacencyMatrixGraph<Local, Double>) this.mapaJogo.clone();
        clonedGraph=resetDificuldadeEstradas(clonedGraph);
        EdgeAsDoubleGraphAlgorithms.shortestPath(clonedGraph, localOrig, localDest, minPath);
        return minPath;
        
    }

    /**
     *
     * @return
     */
    public AdjacencyMatrixGraph<Local, Double> resetDificuldadeEstradas(AdjacencyMatrixGraph<Local, Double> clonedGraph) {
        for (Local local_1 : clonedGraph.vertices()) {
            for (Local local_2 : clonedGraph.directConnections(local_1)) {
                clonedGraph.removeEdge(local_1, local_2);
                clonedGraph.insertEdge(local_1, local_2, (double) 1);
            }
        }
        return clonedGraph;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        MapaJogo mp = (MapaJogo) obj;
        return this.mapaJogo.equals(mp.mapaJogo);
    }

}
