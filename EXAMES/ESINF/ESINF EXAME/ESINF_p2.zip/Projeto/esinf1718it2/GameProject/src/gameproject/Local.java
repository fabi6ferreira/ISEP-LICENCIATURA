/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import java.util.Objects;

/**
 *
 * @author user
 */
public class Local
{
    private String nome;
    private int dificuldade;
    
    public Local(String nome,int dificuldade){
        this.nome = nome;
        this.dificuldade = dificuldade;
    }
    

    /**
     * @return the nome
     */
    public String getNome()
    {
        return nome;
    }

    /**
     * @return the dificuldade
     */
    public int getDificuldade()
    {
        return dificuldade;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome)
    {
        this.nome = nome;
    }



    /**
     * @param dificuldade the dificuldade to set
     */
    public void setDificuldade(int dificuldade)
    {
        this.dificuldade = dificuldade;
    }

    @Override
    public int hashCode()
    {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + this.dificuldade;
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        final Local other = (Local) obj;
        if (!Objects.equals(this.nome, other.nome))
        {
            return false;
        }
        return true;
    }
    
}
