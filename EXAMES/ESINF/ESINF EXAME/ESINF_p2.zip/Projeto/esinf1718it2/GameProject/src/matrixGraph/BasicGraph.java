/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixGraph;

/**
 *
 * @author user
 */
public interface BasicGraph<V,E> {
    int numVertices();
    
    int numEdges();
    
    Iterable<V> vertices();
    
    Iterable<E> edges();
    
    int outDegree(V vertex);
    
    int inDegree(V vertex);
    
    Iterable<E> outgoingEdges(V vertex);
    
    Iterable <E> incomingEdges(V vertex);
    
    E getEdge(V va, V vb);
    
    V[] endVertices(E edge);
    
    boolean insertVertex(V newVertex);
    
    boolean insertEdge(V va, V vb,E newEdge);
    
    boolean removeVertex(V vertex);
    
    E removeEdge(V va,V vb);
}
