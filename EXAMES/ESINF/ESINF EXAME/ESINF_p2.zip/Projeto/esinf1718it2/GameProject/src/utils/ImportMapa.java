/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import gameproject.Local;
import gameproject.MapaJogo;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class ImportMapa {

    private static final String VIRGULA = ",";

    public static boolean importMapa(String fileName, MapaJogo mapaJogo) throws FileNotFoundException {

        Scanner input = new Scanner(new File(fileName));
        String linha;
        boolean caminhos = false;
        String auxLinha[];
        Double dificuldade;

        input.nextLine();
        while (input.hasNext()) {
            linha = input.next();
            //verificar se estamos a ler caminhos ou locais no ficheiro
            if (linha.equalsIgnoreCase("CAMINHOS")) {
                caminhos = true;
                linha = input.next();
            }
            //se nao estivermos a ler caminhos, tratamos da primeira parte do ficheiro, os locais
            if (!caminhos) {
                //guardar local
                auxLinha = linha.split(VIRGULA);
                String nome = auxLinha[0];
                int numeroPontos = Integer.parseInt(auxLinha[1]);
                Local local = new Local(nome, numeroPontos);
                mapaJogo.adicionarLocal(local);
            } else {
                //guardar caminho(estrada)
                auxLinha = linha.split(VIRGULA);
                Local local1 = mapaJogo.getLocalPorNome(auxLinha[0]);
                Local local2 = mapaJogo.getLocalPorNome(auxLinha[1]);

                if (local1 != null && local2 != null) {
                   
                    dificuldade = Double.parseDouble(auxLinha[2]);
                    mapaJogo.adicionarEstrada(local1,local2,dificuldade);
                }
            }
        }
        return mapaJogo.getNumLocais() > 0 && mapaJogo.getNumEstradas() > 0;
    }
}
