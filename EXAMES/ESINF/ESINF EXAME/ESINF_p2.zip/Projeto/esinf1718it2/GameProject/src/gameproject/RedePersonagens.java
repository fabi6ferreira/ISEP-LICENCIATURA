/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameproject;

import adjacencyMap.Edge;
import utils.ImportPersonagens;
import adjacencyMap.Graph;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Set;

/**
 *
 * @author user
 */
public class RedePersonagens {

    //Personagem + Local inical
    private Graph<Personagem, Boolean> grafoPersonagens;

    /*
    para validar locais
     */
    private Controller controller;

    public RedePersonagens(Controller ctrl) {
        grafoPersonagens = new Graph(false);
        this.controller = ctrl;
    }

    public RedePersonagens(RedePersonagens outraRede) {
        this.grafoPersonagens = outraRede.grafoPersonagens.clone();
    }

    public boolean importarDadosPersonagens(String fileName) throws FileNotFoundException {
        return ImportPersonagens.importPersonagens(fileName, this);

    }

    public boolean adicionarPersonagem(Personagem p) {
        return this.grafoPersonagens.insertVertex(p);
    }

    public boolean localInicioDePersonagem(Personagem p, Set<Local> local) {
        return this.controller.inicializarLocal(p, local);
    }

    public boolean adicionarAlianca(Personagem p1, Personagem p2, boolean publica, double fator_Comp) {
        return this.grafoPersonagens.insertEdge(p1, p2, publica, fator_Comp);
    }

    public Graph<Personagem, Boolean> getGraph() {
        return this.grafoPersonagens;
    }

    public Personagem getPersonagemPorNome(String nome) {
        for (Personagem p : grafoPersonagens.vertices()) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                return p;
            }
        }
        return null;
    }

    public Edge<Personagem, Boolean> getAlianca(Personagem p1, Personagem p2) {
        return this.grafoPersonagens.getEdge(p1, p2);
    }

    public boolean removerAlianca(Personagem p1, Personagem p2) {
        return this.grafoPersonagens.removeEdge(p1, p2);
    }

//    public boolean insertEdge(Personagem p1, Personagem p2, Alianca a, double fatorCompatibilidade) {
//        return this.grafoPersonagens.insertEdge(p1, p2, a, fatorCompatibilidade);
//    }
    public int getNumPersonagens() {
        return this.grafoPersonagens.numVertices();
    }

    public int getNumAliancas() {
        return this.grafoPersonagens.numEdges() / 2;
    }

    public boolean existePersonagem(Personagem p) {
        return this.grafoPersonagens.validVertex(p);
    }

    public Local obterLocal(String nomeLocal) {
        return this.controller.obterLocal(nomeLocal);
    }

    public Iterable<Personagem> getListaPersonagens() {
        return this.grafoPersonagens.vertices();
    }

    public Iterable<Edge<Personagem, Boolean>> listaTotalAliancas() {
        return this.grafoPersonagens.edges();
    }

//    public Personagem elementoMaisForte(Personagem p1, Personagem p2) {
//        if (p1.getNumeroPontos() > p2.getNumeroPontos()) {
//            return p1;
//        }
//        return p2;
//    }
    public ArrayList<Personagem> aliadosPersonagem(Personagem p) {
        ArrayList<Personagem> aliados = new ArrayList();
        for (Edge e : this.listaTotalAliancas()) {
            if (e.getVOrig() == p && !aliados.contains(e.getVDest())) {
                aliados.add((Personagem) e.getVDest());
            }
            if (e.getVDest() == p && !aliados.contains(e.getVOrig())) {
                aliados.add((Personagem) e.getVOrig());
            }
        }
        return aliados;
    }

    public double calcularForcaAlianca(Personagem p1, Personagem p2, float fatorCompatibilidade) {
        double forcaAliado1 = p1.getNumeroPontos();
        double forcaAliado2 = p2.getNumeroPontos();
        double forcaAlianca = (forcaAliado1 + forcaAliado2) * fatorCompatibilidade;
        return forcaAlianca;
    }

//    public ArrayList<String> aliancaMaisForte() {
//        ArrayList<String> aliancaMaisForte = new ArrayList<>();
//        String strAlianca;
//        double maximoForca = 0;
//        double forcaAlianca;
//        for (Edge alianca : listaTotalAliancas()) {
//            Personagem p1 = (Personagem) alianca.getVOrig();
//            Personagem p2 = (Personagem) alianca.getVDest();
//            float compatibilidade = (float) alianca.getWeight();
//            forcaAlianca = calcularForcaAlianca(p1, p2, compatibilidade);
//            strAlianca = "Aliança: " + p1.getNome() + " + " + p2.getNome()
//                    + "Força Total: " + forcaAlianca;
//
//
//           if (forcaAlianca > maximoForca) {
//                aliancaMaisForte.clear();
//                aliancaMaisForte.add(strAlianca);
//                maximoForca=forcaAlianca;
//            }
//
//        }
//        return aliancaMaisForte;
//    }
    public String aliancaMaisForte() {
        String aliancaMaisForte = "";
        String strAlianca;

        double maximoForca = 0;
        double forcaAlianca;
        for (Edge alianca : listaTotalAliancas()) {
            Personagem p1 = (Personagem) alianca.getVOrig();
            Personagem p2 = (Personagem) alianca.getVDest();
            float compatibilidade = (float) alianca.getWeight();
            forcaAlianca = calcularForcaAlianca(p1, p2, compatibilidade);
            strAlianca = "Aliança:" + p1.getNome() + ":" + p2.getNome()
                    + ":Força Total:" + forcaAlianca;

            if (forcaAlianca > maximoForca) {
                System.out.println(strAlianca);
                aliancaMaisForte = strAlianca;
                maximoForca = forcaAlianca;
            }

        }
        return aliancaMaisForte;
    }

    public boolean criarNovaAlianca(Personagem a, Personagem b) {
        LinkedList<Personagem> menorCaminho = new LinkedList<>();
        LinkedList<Personagem> aliancasPersonagens = new LinkedList<>();
        if (!existePersonagem(a) && !existePersonagem(b)) {
            return false;
        }
        if (!existeAlianca(a, b)) {
            aliancasPersonagens = caminhoMaisPerto(a, b);
            if (aliancasPersonagens.isEmpty()) {
                return adicionarAlianca(a, b, true, Math.random());
            } else {
                menorCaminho = aliancasPersonagens;
                double fator = novoFatorDeCompatibilidade(menorCaminho);
                return adicionarAlianca(a, b, true, fator);

            }
        }
        return false;
    }

    
    /**
     * "caminho" mais perto ao nível de nós de alianças
     * @param a
     * @param b
     * @return 
     */
    public LinkedList<Personagem> caminhoMaisPerto(Personagem a, Personagem b) {
        Graph<Personagem, Boolean> grafo = this.grafoPersonagens.clone();
        LinkedList<Personagem> list = new LinkedList<>();
        for (Edge e : grafo.edges()) {
            e.setWeight(1);
        }
        adjacencyMap.GraphAlgorithms.shortestPath(grafo, a, b, list);
        System.out.println("teste ALiancas caminho mais curto");
        for(Personagem p : list ){
            System.out.println(p.getNome()+" ");
        }
        return list;
    }

    public double novoFatorDeCompatibilidade(LinkedList<Personagem> menorCaminho) {
        int somaPesos = 0;
        int numPersonagens = 0;
        double fatorDeCompatibilidade;
        Iterable<Edge<Personagem, Boolean>> edges;
        for (int i = 0; i < menorCaminho.size()-1; i++) {
            Personagem p = menorCaminho.get(i);
            edges = grafoPersonagens.outgoingEdges(p);
            for (Edge e1 : edges) {
                if (e1.getVDest() == menorCaminho.get(i + 1)) {
                    somaPesos += e1.getWeight();
                    numPersonagens++;
                }
            }
        }
        fatorDeCompatibilidade = somaPesos / numPersonagens;
        return fatorDeCompatibilidade;
    }

    public boolean existeAlianca(Personagem p1, Personagem p2) {
        return this.aliadosPersonagem(p1).contains(p2) || this.aliadosPersonagem(p2).contains(p1);
    }

    public boolean aliancasPublicas(LinkedList<Personagem> min) {
        Iterable<Edge<Personagem, Boolean>> edges;
        for (int i = 0; i < min.size() - 1; i++) {
            Personagem p1 = min.get(i);
            Personagem p2 = min.get(i + 1);
            Edge alianca = getAlianca(p1, p2);
            if ((boolean) alianca.getElement() == false) {
                return false;
            }
        }
        return true;
    }

//    public Graph<Personagem,Boolean> grafoAliancasPublicas(Graph<Personagem,Boolean> grafoPersonagens){
//        Graph<Personagem,Boolean> grafoAliancasPublicas = this.grafoPersonagens.clone();        
//        ArrayList<Personagem> aliadosPersonagem = new ArrayList<Personagem>();
//        for(Edge alianca : listaTotalAliancas()){
//            alianca.setElement(true);
//        }
//        for(Personagem p : getListaPersonagens()){            
//            for(Personagem p2 : getListaPersonagens()){
//                if(!p.equals(p2) && !existeAlianca(p, p2)){
//                    criarNovaAlianca(p,p2);
//                }else if(!p.equals(p2) && existeAlianca(p,p2)){
//                    
//                }
//            }
//            
//        }
//        
}
