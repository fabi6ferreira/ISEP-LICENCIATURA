/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import gameproject.Local;
import gameproject.Personagem;
import gameproject.RedePersonagens;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author user
 */
public class ImportPersonagens {

    private static final String VIRGULA = ",";

    public static boolean importPersonagens(String fileName, RedePersonagens redePersonagens) throws FileNotFoundException {
        Scanner input = new Scanner(new File(fileName),"UTF-8");
        String linha;
        boolean aliancas = false;
        String auxLinha[];

        input.nextLine();
        while (input.hasNext()) {
            linha = input.next();
            //verificar se estamos a ler personagens ou alianças no ficheiro
            if (linha.equalsIgnoreCase("ALIANÇAS")) {
                System.out.println();
                aliancas = true;
                linha = input.next();
            }
            //se nao estivermos a ler alianças, tratamos da primeira parte do ficheiro, as personagens
            if (!aliancas) {
                //guardar personagem
                auxLinha = linha.split(VIRGULA);
                String nome = auxLinha[0];
                int numeroPontos = Integer.parseInt(auxLinha[1]);
                String nomeLocal = auxLinha[2];
                Local localInicio = redePersonagens.obterLocal(nomeLocal);
                if (nome != null && localInicio != null) {
                    Personagem p = new Personagem(nome, numeroPontos);
                    redePersonagens.adicionarPersonagem(p);
                    Set<Local> local = new HashSet<>();
                    local.add(localInicio);
                    redePersonagens.localInicioDePersonagem(p, local);

                }

            } else {
                auxLinha = linha.split(VIRGULA);

                Personagem p1 = redePersonagens.getPersonagemPorNome(auxLinha[0]);
                Personagem p2 = redePersonagens.getPersonagemPorNome(auxLinha[1]);
                boolean publica;
                if (auxLinha[2].equalsIgnoreCase("TRUE")) {
                    publica = true;
                } else {
                    publica = false;
                }
                double fatorCompatibilidade = Float.parseFloat(auxLinha[3]);

                if (p1 != null && p2 != null) {
                    redePersonagens.adicionarAlianca(p1, p2, publica, fatorCompatibilidade);
                }
            }
        }
               
        return redePersonagens.getNumPersonagens()
                > 0 && redePersonagens.getNumAliancas() > 0;
    }
}
