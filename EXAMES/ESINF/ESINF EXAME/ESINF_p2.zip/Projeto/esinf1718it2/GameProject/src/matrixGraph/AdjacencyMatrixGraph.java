/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixGraph;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author user
 */
public class AdjacencyMatrixGraph<V, E> implements BasicGraph<V, E>, Cloneable {

    public static final int INITIAL_CAPACITY = 10;
    public static final float REZISE_FACTOR = 1.5F;

    int numVertices;
    int numEdges;
    ArrayList<V> vertices;
    E[][] edgeMatrix;

    E privateGet(int x, int y) {
        return edgeMatrix[x][y];
    }

    void privateSet(int x, int y, E e) {
        edgeMatrix[x][y] = e;
    }

    public int toIndex(V vertex) {
        return vertices.indexOf(vertex);
    }

    private void resizeMatrix() {
        if (edgeMatrix.length < numVertices) {
            int newSize = (int) (edgeMatrix.length * REZISE_FACTOR);
            @SuppressWarnings("unchecked")
            E[][] temp = (E[][]) new Object[newSize][newSize];
            for (int i = 0; i < edgeMatrix.length; i++) {
                temp[i] = Arrays.copyOf(edgeMatrix[i], newSize);
            }
            edgeMatrix = temp;

        }
    }

    public AdjacencyMatrixGraph() {
        this(INITIAL_CAPACITY);
    }

    /**
     * Constructs a graph with an initial capacity.
     */
    @SuppressWarnings("unchecked")
    public AdjacencyMatrixGraph(int initialSize) {
        vertices = new ArrayList<V>(initialSize);

        edgeMatrix = (E[][]) new Object[initialSize][initialSize];
    }

    @Override
    public int numVertices() {
        return numVertices;
    }

    @Override
    public int numEdges() {
        return numEdges;
    }

    @Override
    public Iterable<V> vertices() {
        return (Iterable<V>) vertices.clone();
    }

    @Override
    public Iterable<E> edges() {
        ArrayList<E> edges = new ArrayList<E>();
        for (int i = 0; i < numEdges - 1; i++) {
            for (int j = i + 1; j < numVertices; j++) {
                if (edgeMatrix[i][j] != null) {
                    edges.add(edgeMatrix[i][j]);
                }
            }
        }

        return edges;
    }

    @Override
    public int outDegree(V vertex) {
        int index = toIndex(vertex);
        if (index == -1) {
            return -1;
        }
        int edgeCount = 0;
        for (int i = 0; i < numVertices; i++) {
            if (edgeMatrix[index][i] != null) {
                edgeCount++;
            }
        }
        return edgeCount;
    }

    @Override
    public int inDegree(V vertex) {
        return outDegree(vertex);
    }

    public Iterable<V> directConnections(V vertex) {
        ArrayList<V> listaV = new ArrayList<>();
        int ind = toIndex(vertex);

        if (ind == -1) {
            return null;
        }
        for (int i = 0; i < edgeMatrix[0].length; i++) {
            if (edgeMatrix[ind][i] != null) {
                listaV.add(vertices.get(i));
            }
        }
        return listaV;
    }

    @Override
    public Iterable<E> outgoingEdges(V vertex) {
        int index = toIndex(vertex);
        if (index == -1) {
            return null;
        }
        ArrayList<E> listaEdges = new ArrayList<>();
        for (int i = 0; i < numVertices; i++) {
            if (edgeMatrix[index][i] != null) {
                listaEdges.add(edgeMatrix[index][i]);
            }
        }
        return listaEdges;
    }

    @Override
    public Iterable<E> incomingEdges(V vertex) {
        return outgoingEdges(vertex);
    }

    @Override
    public E getEdge(V vertexA, V vertexB) {
        int indexA = toIndex(vertexA);
        if (indexA == -1) {
            return null;
        }
        int indexB = toIndex(vertexB);
        if (indexB == -1) {
            return null;
        }
        return edgeMatrix[indexA][indexB];

    }

    @Override
    public V[] endVertices(E edge) {
        for (int i = 0; i < numVertices - 1; i++) {
            for (int j = i + 1; j < numVertices; j++) {
                if (edgeMatrix[i][j] != null) {
                    if (edgeMatrix[i][j].equals(edge)) {
                        @SuppressWarnings("unchecked")
                        V[] result = (V[]) new Object[2];
                        result[0] = vertices.get(i);
                        result[1] = vertices.get(j);
                        return result;

                    }
                }
            }
        }
        return null;
    }

    @Override
    public boolean insertVertex(V newVertex) {
        int index = toIndex(newVertex);
        if (index != -1) {
            return false;
        }
        vertices.add(newVertex);
        numVertices++;
        resizeMatrix();
        return true;
    }

    public void insertEdge(int indexA, int indexB, E newEdge) {
        edgeMatrix[indexA][indexB] = edgeMatrix[indexB][indexA] = newEdge;
        numEdges++;
    }

    @Override
    public boolean insertEdge(V vertexA, V vertexB, E newEdge) {
        if (vertexA.equals(vertexB)) {
            return false;
        }
        int indexA = toIndex(vertexA);
        if (indexA == -1) {
            return false;
        }
        int indexB = toIndex(vertexB);
        if (indexB == -1) {
            return false;
        }
        if (edgeMatrix[indexA][indexB] != null) {
            return false;
        }
        insertEdge(indexA, indexB, newEdge);
        return true;
    }

    @Override
    public boolean removeVertex(V vertex) {
        int index = toIndex(vertex);
        if (index == -1) {
            return false;
        }
        for (int i = 0; i < numVertices; i++) {
            if (edgeMatrix[index][i] != null) {
                removeEdge(index, i);
            }

        }
        vertices.remove(index);
        numVertices--;
        for (int i = index; i < numVertices; i++) {
            for (int j = 0; j < edgeMatrix.length; j++) {
                edgeMatrix[i][j] = edgeMatrix[i + 1][j];
            }
        }
        for (int j = 0; j < edgeMatrix.length; j++) {
            edgeMatrix[numVertices][j] = null;
        }
        for (int i = index; i < numVertices; i++) {
            for (int j = 0; j < edgeMatrix.length; j++) {
                edgeMatrix[j][i] = edgeMatrix[j][i + 1];
            }
        }
        for (int j = 0; j < edgeMatrix.length; j++) {
            edgeMatrix[j][numVertices] = null;
        }
        return true;
    }
    public E removeEdge(int indexA,int indexB){
        E edge=edgeMatrix[indexA][indexB];
        edgeMatrix[indexA][indexB]=edgeMatrix[indexB][indexA]=null;
        numEdges--;
        return edge;
    }

    @Override
    public E removeEdge(V va, V vb) {
        int indexA=toIndex(va);
        if(indexA==-1){
            return null;
        }
        int indexB=toIndex(vb);
        if(indexB==-1){
            return null;
    }
        return removeEdge(indexA,indexB);
    }
    
   
/**
     * Returns a string representation of the graph. Matrix only represents
     * existence of Edge
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Vertices:\n");
        for (int i = 0; i < numVertices; i++) {
            sb.append(vertices.get(i) + "\n");
        }

        sb.append("\nMatrix:\n");

        sb.append("  ");
        for (int i = 0; i < numVertices; i++) {
            sb.append(" |  " + i + " ");
        }
        sb.append("\n");

        // aligned only when vertices < 10
        for (int i = 0; i < numVertices; i++) {
            sb.append(" " + i + " ");
            for (int j = 0; j < numVertices; j++) {
                if (edgeMatrix[i][j] != null) {
                    sb.append("|  X  ");
                } else {
                    sb.append("|     ");
                }
            }
            sb.append("\n");
        }

        sb.append("\nEdges:\n");

        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                if (edgeMatrix[i][j] != null) {
                    sb.append("From " + i + " to " + j + "-> " + edgeMatrix[i][j] + "\n");
                }
            }
        }

        sb.append("\n");

        return sb.toString();
    }

    /**
     * Returns a clone of the graph (a shallow copy).
     *
     * @return the new cloned graph
     */
    @SuppressWarnings("unchecked")
    public Object clone() {
        AdjacencyMatrixGraph<V, E> newObject = new AdjacencyMatrixGraph<V, E>();

        newObject.vertices = (ArrayList<V>) vertices.clone();

        newObject.numVertices = numVertices;

        newObject.edgeMatrix = (E[][]) new Object[edgeMatrix.length][edgeMatrix.length];

        for (int i = 0; i < edgeMatrix.length; i++) {
            newObject.edgeMatrix[i] = Arrays.copyOf(edgeMatrix[i], edgeMatrix.length);
        }

        newObject.numEdges = numEdges;

        return newObject;
    }

    /**
     * Implementation of equals
     *
     * @param the other graph to test for equality
     * @return true if both objects represent the same graph
     */
    public boolean equals(Object oth) {

        if (oth == null) {
            return false;
        }

        if (this == oth) {
            return true;
        }

        if (!(oth instanceof AdjacencyMatrixGraph<?, ?>)) {
            return false;
        }

        AdjacencyMatrixGraph<?, ?> other = (AdjacencyMatrixGraph<?, ?>) oth;

        if (numVertices != other.numVertices || numEdges != other.numEdges) {
            return false;
        }

        if (!vertices.equals(other.vertices)) {
            return false;
        }

        if (!Arrays.deepEquals(edgeMatrix, other.edgeMatrix)) {
            return false;
        }

        // fails to recognise difference between objects with different <E> type
        // when vertices are the same and both graphs have no edges
        return true;
    }
    
}
