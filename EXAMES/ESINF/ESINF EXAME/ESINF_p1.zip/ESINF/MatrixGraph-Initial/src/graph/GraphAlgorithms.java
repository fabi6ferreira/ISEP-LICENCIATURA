package graph;

import java.util.LinkedList;
import java.util.Iterator;

/**
 * Implementation of graph algorithms for a (undirected) graph structure
 * Considering generic vertex V and edge E types
 *
 * Works on AdjancyMatrixGraph objects
 *
 * @author DEI-ESINF
 *
 */
public class GraphAlgorithms {

    private static <T> LinkedList<T> reverse(LinkedList<T> list) {
        LinkedList<T> reversed = new LinkedList<>();
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            reversed.push(it.next());
        }
        return reversed;
    }

    /**
     * Performs depth-first search of the graph starting at vertex. Calls
     * package recursive version of the method.
     *
     * @param <V>
     * @param <E>
     * @param graph Graph object
     * @param vertex Vertex of graph that will be the source of the search
     * @return queue of vertices found by search (including vertex), null if
     * vertex does not exist
     *
     */
    public static <V, E> LinkedList<V> DFS(AdjacencyMatrixGraph<V, E> graph, V vertex) {

        int index = graph.toIndex(vertex);
        if (index == -1) {
            return null;
        }

        LinkedList<V> resultQueue = new LinkedList<>();
        resultQueue.add(vertex);
        boolean[] knownVertices = new boolean[graph.numVertices];
        DFS(graph, index, knownVertices, resultQueue);
        return resultQueue;
    }

    /**
     * Actual depth-first search of the graph starting at vertex. The method
     * adds discovered vertices (including vertex) to the queue of vertices
     *
     * @param graph Graph object
     * @param index Index of vertex of graph that will be the source of the
     * search
     * @param known previously discovered vertices
     * @param verticesQueue queue of vertices found by search
     *
     */
    static <V, E> void DFS(AdjacencyMatrixGraph<V, E> graph, int index, boolean[] knownVertices, LinkedList<V> verticesQueue) {
        knownVertices[index] = true;
        for (int i = 0; i < graph.numVertices; i++) {
            if (graph.edgeMatrix[index][i] != null && knownVertices[i] == false) {
                verticesQueue.add(graph.vertices.get(i));
                DFS(graph, i, knownVertices, verticesQueue);
            }
        }
    }

    /**
     * Performs breath-first search of the graph starting at vertex. The method
     * adds discovered vertices (including vertex) to the queue of vertices
     *
     * @param <V>
     * @param <E>
     * @param graph Graph object
     * @param vertex Vertex of graph that will be the source of the search
     * @return queue of vertices found by search (including vertex), null if
     * vertex does not exist
     *
     */
    public static <V, E> LinkedList<V> BFS(AdjacencyMatrixGraph<V, E> graph,
            V vertex) {
        if (!graph.checkVertex(vertex)) {
            return null;
        } else {
            LinkedList<V> qbfs = new LinkedList<>();
            LinkedList<V> qaux = new LinkedList<>();
            qbfs.add(vertex);
            qaux.add(vertex);
            while (!qaux.isEmpty()) {
                qaux.clear();
                for (V vert : qbfs) {
                    for (V vAdj : graph.directConnections(vert)) {
                        if (!qbfs.contains(vAdj) && !qaux.contains(vAdj)) {
                            qaux.add(vAdj);
                        }
                    }
                }
                for (V vert : qaux) {
                    qbfs.add(vert);
                }
            }
            return qbfs;
        }
    }

    /**
     * All paths between two vertices Calls recursive version of the method.
     *
     * @param <V>
     * @param <E>
     * @param graph Graph object
     * @param source Source vertex of path
     * @param dest Destination vertex of path
     * @param paths
     * @return false if vertices not in the graph
     *
     */
    public static <V, E> boolean allPaths(AdjacencyMatrixGraph<V, E> graph,
            V source, V dest, LinkedList<LinkedList<V>> paths) {
        if (graph.checkVertex(source) && graph.checkVertex(dest)) {
            paths.clear();
            boolean[] knownVertices = new boolean[graph.numVertices()];
            LinkedList<V> auxStack = new LinkedList<>();
            allPaths(graph, graph.toIndex(source), graph.toIndex(dest),
                    knownVertices, auxStack, paths);
            return paths.size() > 0;
        }
        return false;
    }

    /**
     * Actual paths search The method adds vertices to the current path (stack
     * of vertices) when destination is found, the current path is saved to the
     * list of paths
     *
     * @param graph Graph object
     * @param sourceIdx Index of source vertex
     * @param destIdx Index of destination vertex
     * @param knownVertices previously discovered vertices
     * @param auxStack stack of vertices in the path
     * @param path LinkedList with paths (queues)
     *
     */
    static <V, E> void allPaths(AdjacencyMatrixGraph<V, E> graph, int sourceIdx,
            int destIdx, boolean[] knownVertices, LinkedList<V> auxStack,
            LinkedList<LinkedList<V>> paths) {
        V vOrig = graph.vertices.get(sourceIdx);
        V vDst = graph.vertices.get(destIdx);
        knownVertices[sourceIdx] = true;
        auxStack.push(vOrig);
        for (V vAdj : graph.directConnections(vOrig)) {
            int adjIdx = graph.toIndex(vAdj);
            if (vAdj == vDst) {
                auxStack.push(vDst);
                paths.add(GraphAlgorithms.reverse(auxStack));
                auxStack.pop();
            } else {
                if (!knownVertices[adjIdx]) {
                    allPaths(graph, adjIdx, destIdx, knownVertices, auxStack,
                            paths);
                }
            }
        }
        knownVertices[sourceIdx] = false;
        auxStack.pop();
    }

    /**
     * Transforms a graph into its transitive closure uses the Floyd-Warshall
     * algorithm
     *
     * @param <V>
     * @param <E>
     * @param graph Graph object
     * @param dummyEdge object to insert in the newly created edges
     * @return the new graph
     * @throws java.lang.CloneNotSupportedException
     */
    public static <V, E> AdjacencyMatrixGraph<V, E> transitiveClosure(
            AdjacencyMatrixGraph<V, E> graph, E dummyEdge) throws CloneNotSupportedException {
        AdjacencyMatrixGraph<V, E> newGraph = (AdjacencyMatrixGraph<V, E>) graph.clone();
        for (int k = 0; k < newGraph.numVertices(); k++) {
            V vK = newGraph.vertices.get(k);
            for (int i = 0; i < newGraph.numVertices(); i++) {
                V vI = newGraph.vertices.get(i);
                if (i != k && newGraph.getEdge(vI, vK) != null) {
                    for (int j = 0; j < newGraph.numVertices(); j++) {
                        V vJ = newGraph.vertices.get(j);
                        if (i != j && k != j && newGraph.getEdge(vK, vJ) != null) {
                            newGraph.insertEdge(vI, vJ, dummyEdge);
                        }
                    }
                }
            }
        }
        return newGraph;
    }

}
