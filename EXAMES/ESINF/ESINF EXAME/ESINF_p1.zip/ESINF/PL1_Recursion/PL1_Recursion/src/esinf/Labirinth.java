package esinf;

/**
 *
 * @author DEI-ESINF
 */
public class Labirinth {

    /**
     *
     * @param actual the labirinth in its actual (marked) form
     * @param y coordinate y in the labirinth
     * @param x coordinate x in the labirinth
     * @return the marked labirinth or null if there is no way
     */
    public static int[][] check(int[][] actual, int y, int x) {

        actual[y][x] = 9;                //parto do principio que estou numa posiÃ§Ã£o vÃ¡lida
        int[][] result = null;

        if (y == actual.length - 1 && x == actual[0].length - 1) {
            return actual;

        }
        //MOVIMENTO NORTE
        if (validaPosicao(actual, y - 1, x)) {      //movimento para norte e sua validaÃ§Ã£o
            result = check(actual, y - 1, x);
            if (result != null) {                  // para o caso de retornar null
                return result;
            }

        }
        //MOVIMENTO ESTE
        if (validaPosicao(actual, y, x + 1)) {      //movimento para norte e sua validaÃ§Ã£o
            result = check(actual, y, x + 1);
            if (result != null) {                  // para o caso de retornar null
                return result;
            }

        }
        //MOVIMENTO SUL
        if (validaPosicao(actual, y + 1, x)) {      //movimento para norte e sua validaÃ§Ã£o
            result = check(actual, y + 1, x);
            if (result != null) {                  // para o caso de retornar null
                return result;
            }

        }
        //MOVIMENTO OESTE
        if (validaPosicao(actual, y, x - 1)) {      //movimento para norte e sua validaÃ§Ã£o
            result = check(actual, y, x - 1);
            if (result != null) {                  // para o caso de retornar null
                return result;
            }

        }
        actual[y][x] = 2;
        return null;
    }

    private static boolean validaPosicao(int[][] actual, int y, int x) {
        //se estÃ¡ fora dos parametros da matriz e o valor contido nessa posiÃ§Ã£o
        return !(y < 0 || y > actual.length - 1 || x < 0 || x > actual[0].length - 1 || actual[y][x] != 1);

    }

}
