/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esinf;

import java.time.LocalDate;
import java.util.*;

/**
 *
 * @author DEI-ISEP
 */
public class Supermarket {

    Map<Invoice, Set<Product>> m;

    Supermarket() {
        m = new HashMap<>();
    }

    // Reads invoices from a list of String
    void getInvoices(List<String> l) throws Exception {
        HashSet<Product> hsp = new HashSet<>();

        for (int i = 0; i < l.size(); i++) {
            String[] aux = l.get(i).split(",");

            if (l.get(i).charAt(0) == 'I') {
                Invoice inv = new Invoice(aux[1], aux[2]);
                hsp = new HashSet<>();

                m.put(inv, hsp);
            }
            if (l.get(i).charAt(0) == 'P') {
                Product p = new Product(aux[1], Integer.parseInt(aux[2]), Long.parseLong(aux[3]));

                hsp.add(p);
            }
        }
    }

    // returns a set in which each number is the number of products in the r
    // invoice 
    Map<Invoice, Integer> numberOfProductsPerInvoice() {
        HashMap<Invoice, Integer> res = new HashMap<>();
        for (Map.Entry<Invoice, Set<Product>> entry : m.entrySet()) {
            Invoice inv = entry.getKey();
            Set<Product> hsp = entry.getValue();
            res.put(inv, hsp.size());
        }
        return res;
    }

    // returns a Set of invoices in which each date is >d1 and <d2
    Set<Invoice> betweenDates(LocalDate d1, LocalDate d2) {

        Set<Invoice> res = new HashSet<>();
        for (Map.Entry<Invoice, Set<Product>> entry : m.entrySet()) {
            Invoice inv = entry.getKey();
            if (inv.getDate().isAfter(d1) && inv.getDate().isBefore(d2)) {
                res.add(inv);
            }
        }
        return res;
    }

    // returns the sum of the price of the product in all the invoices
    long totalOfProduct(String productId) {

        long sum = 0;
        for (Map.Entry<Invoice, Set<Product>> entry : m.entrySet()) {
            Set<Product> hsp = entry.getValue();
            for (Product p : hsp) {
                if (p.getIdentification().equals(productId)) {
                    sum += p.getPrice() * p.getQuantity();
                }
            }
        }
        return sum;
    }

    // converts a map of invoices and troducts to a map which key is a product 
    // identification and the values are a set of the invoice references 
    // in which it appearss
    Map<String, Set<Invoice>> convertInvoices() {

        HashMap<String, Set<Invoice>> res = new HashMap<>();

        for (Map.Entry<Invoice, Set<Product>> entry : m.entrySet()) {
            Set<Invoice> hsi = new HashSet<>();
            Invoice inv = entry.getKey();
            hsi.add(inv);
            Set<Product> hsp = entry.getValue();
            for (Product p : hsp) {
                if (res.containsKey(p.getIdentification())) {
                    hsi = res.get(p.getIdentification());
                    hsi.add(inv);
                } else {
                    res.put(p.getIdentification(), hsi);
                }
            }
        }
        return res;
    }
}
